package com.cg.ibs.rm.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigInteger;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.junit.jupiter.api.Test;

import com.cg.ibs.rm.bean.CreditCard;
import com.cg.ibs.rm.exception.IBSExceptions;

class CreditCardServiceImplTest {
	CreditCardServiceImpl obj = new CreditCardServiceImpl();
	Bank_AdminServiceImpl obj1 = new Bank_AdminServiceImpl();

	@Test
	public void test1ValidateNameOnCard() {
		assertTrue(obj.validateNameOnCard("qwertyysdhdbhdsbsdijh"));

	}

	@Test
	public void test2ValidateNameOnCard() {
		assertFalse(obj.validateNameOnCard("123564564"));

	}

	@Test
	public void test3ValidateNameOnCard() {
		assertEquals(false, obj.validateNameOnCard("!@##$@#$%#%^$^&%"));

	}

	@Test
	final void test1DeleteCardDetails() {
		try {
			assertTrue(obj.deleteCardDetails(new BigInteger("1234567890123456")));
		} catch (IBSExceptions exception) {
			Throwable throwable = assertThrows(IBSExceptions.class, () -> {
				throw new IBSExceptions(exception.getMessage());
			});

			assertSame("Credit card doesn't exist", throwable.getMessage());

		}
	}

	@Test
	final void test2DeleteCardDetails() {
		try {
			assertFalse(obj.deleteCardDetails(new BigInteger("1231672789250000")));
		} catch (IBSExceptions exception) {
			Throwable throwable = assertThrows(IBSExceptions.class, () -> {
				throw new IBSExceptions(exception.getMessage());
			});

			assertSame("Credit card doesn't exist", throwable.getMessage());

		}
	}

	@Test
	final void test3DeleteCardDetails() {
		try {
			assertEquals(true, obj.deleteCardDetails(new BigInteger("1234567890123456")));
		} catch (IBSExceptions exception) {
			Throwable throwable = assertThrows(IBSExceptions.class, () -> {
				throw new IBSExceptions(exception.getMessage());
			});
			assertSame("Credit card doesn't exist", throwable.getMessage());
		}
	}

	@Test
	final void test1SaveCardDetails() {
		CreditCard card = new CreditCard();
		card.setCardNumber(new BigInteger("1234567890123456"));
		DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		String dateString = "14/07/2019";
		LocalDate localDate = LocalDate.parse(dateString, dateTimeFormatter);
		card.setDateOfExpiry(localDate);
		card.setNameOnCard("Saima");
		try {
			obj.saveCardDetails(new BigInteger("5555111151513301"), card);
			assertEquals(2, obj1.showUnapprovedCreditCards(new BigInteger("5555111151513301")).size());
		} catch (IBSExceptions exception) {
			Throwable throwable = assertThrows(IBSExceptions.class, () -> {
				throw new IBSExceptions(exception.getMessage());
			});
			assertSame("Credit card already added", throwable.getMessage());
		}
	}

	@Test
	final void test2SaveCardDetails() {
		CreditCard card = new CreditCard();
		card.setCardNumber(new BigInteger("1234567890123456"));
		DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		String dateString = "14/07/2019";
		LocalDate localDate = LocalDate.parse(dateString, dateTimeFormatter);
		card.setDateOfExpiry(localDate);
		card.setNameOnCard("saima");
		try {
			obj.saveCardDetails(new BigInteger("5555111151513301"), card);
			assertNotNull((obj1.showUnapprovedCreditCards(new BigInteger("5555111151513301")).size()));
		} catch (IBSExceptions exception) {
			Throwable throwable = assertThrows(IBSExceptions.class, () -> {
				throw new IBSExceptions(exception.getMessage());
			});
			assertSame("Credit card already added", throwable.getMessage());
		}

	}

}
