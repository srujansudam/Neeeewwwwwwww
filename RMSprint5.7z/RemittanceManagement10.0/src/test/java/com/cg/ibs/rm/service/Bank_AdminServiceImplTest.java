package com.cg.ibs.rm.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.math.BigInteger;
import java.time.LocalDate;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.ibs.rm.bean.Beneficiary;
import com.cg.ibs.rm.bean.CreditCard;
import com.cg.ibs.rm.exception.IBSExceptions;
import com.cg.ibs.rm.ui.Type;

@Component("BankAdminServiceTest")
class Bank_AdminServiceImplTest {
	@Autowired
	Bank_AdminService object;
	@Autowired
	BeneficiaryAccountServiceImpl object1;
	@Autowired
	CreditCardServiceImpl object2;
	Beneficiary beneficiary = new Beneficiary();

	@Test
	@Disabled
	public void testShowRequests1() {
		assertEquals(3, object.showRequests().size());
	}

	@Test
	public void testShowRequests2() {
		assertNotNull(object.showRequests());
	}

	@Test
	public void testShowUnapprovedCreditCards1() {
		assertEquals(2, object.showUnapprovedCreditCards(new BigInteger("5555111151513301")).size());
	}

	@Test
	public void testShowUnapprovedCreditCards2() {
		assertNotNull(object.showUnapprovedCreditCards(new BigInteger("5555111151513301")));
	}

	@Test
	public void testShowUnapprovedBeneficiaries1() {
		assertEquals(1, object.showUnapprovedBeneficiaries(new BigInteger("5555111151513301")).size());
	}

	@Test
	public void testShowUnapprovedBeneficiaries2() {
		assertNotNull(object.showUnapprovedCreditCards(new BigInteger("5555111151513301")));
	}

	
	@Test
	public void testSaveCreditCardDetails1() {
		CreditCard card = new CreditCard();
		card.setCardNumber(new BigInteger("1234567890129999"));
		card.setDateOfExpiry(LocalDate.now());
		card.setNameOnCard("Neel1");
		
		try {
			object.saveCreditCardDetails(card.getCardNumber());
			assertEquals(1, object2.showCardDetails(new BigInteger("5555111151513301")).size());
		} catch (IBSExceptions exception) {
			Throwable throwable = assertThrows(IBSExceptions.class, () -> {
				throw new IBSExceptions(exception.getMessage());
			});
			assertSame("Credit card doesn't exist", throwable.getMessage());
		}
	}
	
	@Test
	public void testSaveBeneficiaryDetails1() {
		beneficiary.setAccountNumber(new BigInteger("12345678901"));
		beneficiary.setAccountName("Ayush Handsome");
		beneficiary.setBankName("SBSC");
		beneficiary.setIfscCode("SBSC5623487");
		beneficiary.setType(Type.OTHERSINOTHERS);
		try {
			object.saveBeneficiaryDetails(beneficiary.getAccountNumber());
		
		assertEquals(1, object1.showBeneficiaryAccount(new BigInteger("5555111151513301")).size());
		}catch (IBSExceptions exception) {
			Throwable throwable = assertThrows(IBSExceptions.class, () -> {
				throw new IBSExceptions(exception.getMessage());
			});
			assertSame("Beneficiary doesn't exist", throwable.getMessage());
		}
	}

}
