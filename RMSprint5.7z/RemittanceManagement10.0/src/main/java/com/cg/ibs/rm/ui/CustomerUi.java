package com.cg.ibs.rm.ui;

public enum CustomerUi {
		CREDITCARD, BENEFICIARY, AUTOPAYMENT, EXIT
}
