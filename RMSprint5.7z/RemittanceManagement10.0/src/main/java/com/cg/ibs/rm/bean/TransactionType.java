package com.cg.ibs.rm.bean;

public enum TransactionType {
	DEBIT,CREDIT
}
