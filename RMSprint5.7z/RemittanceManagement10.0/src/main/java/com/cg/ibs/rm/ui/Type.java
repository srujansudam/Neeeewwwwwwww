package com.cg.ibs.rm.ui;

public enum Type {
	MYACCOUNTINIBS, MYACCOUNTINOTHERBANKS, OTHERSACCOUNTINIBS, OTHERSACCOUNTINOTHERBANKS
}



//creditcard expiry date
//exceptions not working
