package com.cg.ibs.rm.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Set;
import java.util.regex.Pattern;

import javax.persistence.EntityTransaction;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ibs.rm.bean.AutoPayment;
import com.cg.ibs.rm.bean.ServiceProvider;
import com.cg.ibs.rm.bean.ServiceProviderId;
import com.cg.ibs.rm.dao.AutoPaymentDAO;
import com.cg.ibs.rm.exception.IBSExceptions;
import com.cg.ibs.rm.util.JpaUtil;

@Service("AutoPaymentService")
public class AutoPaymentServiceImpl implements AutoPaymentService {
	EntityTransaction transaction;
	@Autowired
	private AutoPaymentDAO autoPaymentDao;
	private static final Logger LOGGER = Logger.getLogger(AutoPaymentServiceImpl.class.getName());

	@Override
	public Set<AutoPayment> showAutopaymentDetails(BigInteger uci) throws IBSExceptions {
		LOGGER.info("entered showAutopaymentDetails in autopaymentservimpl");
		return autoPaymentDao.getAutopaymentDetails(uci);

	}

	@Override
	public Set<ServiceProvider> showIBSServiceProviders() {
		LOGGER.info("entered  showIBSServiceProviders in autopaymentservimpl");
		return autoPaymentDao.showServiceProviderList();

	}

	@Override
	public boolean autoDeduction(BigInteger uci, BigInteger accountNumber, AutoPayment autoPayment)
			throws IBSExceptions {
		LOGGER.info("entered  autodeduction in autopaymentservimpl");
		transaction = JpaUtil.getTransaction();
		LocalDate today = LocalDate.now();
		boolean validAutoDeduct = false;
		LOGGER.debug(autoPaymentDao.getAccount(accountNumber).getBalance());
		if (Pattern.matches("^(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[012])/((?:[0-9]{2})?[0-9]{2})$",
				autoPayment.getDateOfStart())) {
			DateTimeFormatter dtFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate startOfAutoPayment = LocalDate.parse(autoPayment.getDateOfStart(), dtFormatter);
			if (!transaction.isActive()) {
				transaction.begin();
			}
			if (!(startOfAutoPayment.isBefore(today))) {
				autoPaymentDao.copyDetails(uci, autoPayment);
				if (today.equals(startOfAutoPayment) && (0 <= autoPaymentDao.getAccount(accountNumber).getBalance()
						.compareTo(autoPayment.getAmount()))) {
					BigDecimal balance = autoPaymentDao.getAccount(accountNumber).getBalance()
							.subtract(autoPayment.getAmount());
					autoPaymentDao.setCurrentBalance(balance, accountNumber);
					autoPaymentDao.setTransaction(uci, accountNumber, autoPayment);
					startOfAutoPayment.plusMonths(1);
					LOGGER.debug(autoPaymentDao.getAccount(accountNumber).getBalance());

				}
				validAutoDeduct = true;
				transaction.commit();
			}
		}
		return validAutoDeduct;
	}

	@Override
	public boolean deleteAutopayment(BigInteger uci, BigInteger spi) throws IBSExceptions {
		boolean result = false;
		LOGGER.info("entered updateRequirements in autopaymentservimpl");
		EntityTransaction transaction = JpaUtil.getTransaction();
		if (!transaction.isActive()) {
			transaction.begin();
		}
		result = autoPaymentDao.deleteDetails(uci, spi);
		transaction.commit();
		return result;
	}

	@Override
	public boolean validEndDate(String endDate, String startDate) {
		boolean validDate = false;
		if (Pattern.matches("^((0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[012])/(?:[0-9]{2})?[0-9]{2})$", endDate)) {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate endDate1 = LocalDate.parse(endDate, formatter);
			LocalDate startDate1 = LocalDate.parse(startDate, formatter);
			if (!endDate1.isBefore(startDate1)) {
				validDate = true;
			} else {
				validDate = false;
			}
		}
		return validDate;
	}

	@Override
	public boolean updateDetails(ServiceProviderId providerId, AutoPayment autoPayment) throws IBSExceptions {
		boolean validModify = false;
		transaction = JpaUtil.getTransaction();
		if (!transaction.isActive()) {
			transaction.begin();
		}
		AutoPayment autoPayment2 = autoPaymentDao.getAutopayment(providerId);
		if (autoPayment.getAmount() != null) {
			autoPayment2.setAmount(autoPayment.getAmount());
		}
		if (autoPayment.getDateOfEnd() != null) {
			autoPayment2.setDateOfEnd(autoPayment.getDateOfEnd());
		}
		if (autoPayment.getDateOfStart() != null) {
			autoPayment2.setDateOfStart(autoPayment.getDateOfStart());
		}
		if (autoPaymentDao.updateDetails(autoPayment2)) {
			validModify = true;
		}
		transaction.commit();
		return validModify;
	}

	@Override
	public AutoPayment getAutopayment(ServiceProviderId providerId) throws IBSExceptions {
		return autoPaymentDao.getAutopayment(providerId);
	}

}